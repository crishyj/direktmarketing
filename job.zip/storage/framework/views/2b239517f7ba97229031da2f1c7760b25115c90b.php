<?php
    $page = config('site.page');
?>

<nav class="sidebar sidebar-bunker">
        <div class="sidebar-header">
            <!--<a href="" class="logo"><span>bd</span>task</a>-->
            <a class="navbar-brand logo" href="<?php echo e(url('/dashboard')); ?>">
                 <?php echo e(config('app.name', 'Laravel')); ?>

            </a>
        </div><!--/.sidebar header-->
        <div class="profile-element d-flex align-items-center flex-shrink-0">
            <div class="avatar online">
                <img src="<?php echo e(asset('dash_asset/dist/img/avatar.png')); ?>" class="img-fluid rounded-circle" alt="">
            </div>
            <div class="profile-text">
                <h6 class="m-0"><?php echo e(Auth::user()->name); ?></h6>
                
            </div>
        </div><!--/.profile element-->
        
        <div class="sidebar-body">
            <nav class="sidebar-nav">
                <ul class="metismenu">
                    <li class="nav-label">Main Menu</li>
                    <li class="<?php if($page == 'dashboard'): ?> mm-active <?php endif; ?>">
                        <a class="has-arrow material-ripple" href="<?php echo e(route('dashboard.admin')); ?> ">
                            <i class="typcn typcn-home-outline mr-2"></i>
                            Dashboard
                        </a>
                        
                    </li>
                    <li class="<?php if($page == 'adword'): ?> mm-active <?php endif; ?>">
                        <a class="has-arrow material-ripple" href=" <?php echo e(route('dashboard.adwords')); ?> ">
                            <i class="typcn typcn-social-google-plus-circular"></i>
                            Google Adwords
                        </a>
                    </li>

                    <li class="<?php if($page == 'advertise'): ?> mm-active <?php endif; ?>">
                        <a class="has-arrow material-ripple" href=" <?php echo e(route('advertise.index')); ?> ">
                            <i class="typcn typcn-social-google-plus-circular"></i>
                            Advertise
                        </a>
                    </li>

                    <li class="<?php if($page == 'oneform'): ?> mm-active <?php endif; ?>">
                        <a class="has-arrow material-ripple" href=" <?php echo e(route('dashboard.oneform')); ?> ">
                            <i class="typcn typcn-social-google-plus-circular"></i>
                            OneForm
                        </a>
                    </li>
                    
                </ul>
            </nav>
        </div><!-- sidebar-body -->
    </nav><?php /**PATH E:\2019\Andreas\job\resources\views/layouts/aside.blade.php ENDPATH**/ ?>