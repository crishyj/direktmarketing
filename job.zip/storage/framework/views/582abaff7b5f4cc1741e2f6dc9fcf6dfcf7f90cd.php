<div>

    <h1>Hello!</h1>
    <h2>My name is <?php echo e($name); ?> </h2>
    <h2>E-mail: <?php echo e($email); ?></h2>
    <h2>Phone: <?php echo e($phone); ?></h2>
    <h2>Proposals:</h2>
    <h4>
        <?php echo e($porposal); ?>

    </h4>      
    
</div><?php /**PATH /var/www/vhosts/direktmarketing-boerse.com/httpdocs/resources/views/emails/contact.blade.php ENDPATH**/ ?>