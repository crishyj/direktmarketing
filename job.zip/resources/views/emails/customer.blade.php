<div>
    <h1>Hello! {{$name}} </h1>
    <h3>Here is your email verification code. </h3>
    <h4>
            {{$verify}}
    </h4>
    
    
</div>