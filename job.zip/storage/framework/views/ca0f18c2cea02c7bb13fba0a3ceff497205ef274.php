<!DOCTYPE html>
<html lang="en">

<head>
    <META HTTP-EQUIV="content-type" CONTENT="text/html; charset=utf-8">
    <title><?php echo e(config('app.name')); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta name="csrf_token" content="<?php echo e(csrf_token()); ?>" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link href="<?php echo e(asset('view/img/favicon.ico')); ?>" rel="icon" type="image/x-icon" class="js-site-favicon" >
    <link href="<?php echo e(asset('view/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('view/css/animate.css')); ?>" rel="stylesheet" >
    <link href="<?php echo e(asset('view/css/fontawesome/css/all.min.css')); ?>" rel="stylesheet" >
    <!--<link href="<?php echo e(asset('view/css/freshslider.min.css')); ?>" rel="stylesheet" >-->
    <link href="<?php echo e(asset('view/css/main.css')); ?>" rel="stylesheet">
</head>

<body class="page1">
        <div id="ajax-loading" class="text-center">
            <img class="mx-auto" src="<?php echo e(asset('images/loader.gif')); ?>" width="70" alt="" style="margin:45vh auto;">
        </div>
    <?php echo $__env->yieldContent('content'); ?>

    <script src="<?php echo e(asset('view/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('view/js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('view/js/bootstrap.min.js')); ?>"></script>
    <!--<script src="<?php echo e(asset('view/js/freshslider.min.js')); ?>"></script>  -->

    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    </script>  

    <?php echo $__env->yieldContent('script'); ?>

</body>
<?php /**PATH /home2/richdilly/crm.dillahunty.space/resources/views/layouts/customer.blade.php ENDPATH**/ ?>