<nav class="sidebar sidebar-bunker">
        <div class="sidebar-header">
            <!--<a href="" class="logo"><span>bd</span>task</a>-->
            <a class="navbar-brand logo" href="<?php echo e(url('/dashboard')); ?>">
                 <?php echo e(config('app.name', 'Laravel')); ?>

            </a>
        </div><!--/.sidebar header-->
        <div class="profile-element d-flex align-items-center flex-shrink-0">
            <div class="avatar online">
                <img src="<?php echo e(asset('dash_asset/dist/img/avatar.png')); ?>" class="img-fluid rounded-circle" alt="">
            </div>
            <div class="profile-text">
                <h6 class="m-0"><?php echo e(Auth::user()->name); ?></h6>
                
            </div>
        </div><!--/.profile element-->
        
        <div class="sidebar-body">
            <nav class="sidebar-nav">
                <ul class="metismenu">
                    <li class="nav-label">Main Menu</li>
                    <li class="mm-active">
                        <a class="has-arrow material-ripple" href="#">
                            <i class="typcn typcn-home-outline mr-2"></i>
                            Dashboard
                        </a>
                        
                    </li>
                    
                </ul>
            </nav>
        </div><!-- sidebar-body -->
    </nav><?php /**PATH /var/www/vhosts/direktmarketing-boerse.com/httpdocs/resources/views/layouts/aside.blade.php ENDPATH**/ ?>