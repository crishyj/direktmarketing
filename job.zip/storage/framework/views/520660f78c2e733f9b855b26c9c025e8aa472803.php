<div>
    <h1>Hello! <?php echo e($name); ?> </h1>
    <h3>Here is your email verification code. </h3>
    <h4>
            <?php echo e($verify); ?>

    </h4>
    
    
</div><?php /**PATH /home2/richdilly/crm.dillahunty.space/resources/views/emails/customer.blade.php ENDPATH**/ ?>