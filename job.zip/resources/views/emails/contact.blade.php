<div>

    <h1>Hello!</h1>
    <h2>My name is {{$name}} </h2>
    <h2>E-mail: {{$email}}</h2>
    <h2>Phone: {{$phone}}</h2>
    <h2>Proposals:</h2>
    <h4>
        {{$porposal}}
    </h4>      
    
</div>