<p>
    <strong>Name: </strong>  <?php echo e($id->name); ?>

</p>

<p>
    <strong>Email: </strong>  <?php echo e($id->email); ?>

</p>

<p>
    <strong>Phone: </strong>  <?php echo e($id->phone); ?>

</p>

<p>
    <strong>Company: </strong>  <?php echo e($id->company); ?>

</p>

<p>
    <strong>Budget: </strong> $ <?php echo e($id->budget); ?> USD
</p>

<p>
    <strong>Title:</strong> <?php echo e($id->title); ?>  
</p>

<p>
    <strong>Description:</strong> <?php echo e($id->target_group_desc); ?>  
</p>

<p>
    <strong>Category</strong>
</p>
<div>
    <ul>
        <li>
                <strong> E-Mail Marketing: </strong> 
                <?php
                    echo ($id-> email_marketing ==1)?"Yes":"No";
                ?>
        </li>
        <li>
                <strong> Callcenter Action: </strong> 
                <?php
                    echo ($id-> callcenter ==1)?"Yes":"No";
                ?>
            </li>
            <li>
                <strong> Postal Addresses: </strong> 
                <?php
                    echo ($id-> postal_Address ==1)?"Yes":"No";
                ?>
            </li>
    </ul>
</div>


<div>
    <p>
        <strong>Country</strong>
    </p>
    <ul>
        <li>
                <strong> Germany: </strong> 
                <?php
                    echo ($id-> germany ==1)?"Yes":"No";
                ?>
        </li>
        <li>
                <strong> Austria : </strong> 
                <?php
                    echo ($id-> austria ==1)?"Yes":"No";
                ?>
        </li>
           
    </ul>
</div>

<div>
    <p>
        <strong>Supplier</strong>
    </p>
    <ul>
        <li>
                <strong> Company: </strong> 
                <?php
                    echo ($id-> supplier_company ==1)?"Yes":"No";
                ?>
        </li>
        <li>
                <strong> Personal : </strong> 
                <?php
                    echo ($id-> austria ==1)?"Yes":"No";
                ?>
            </li>
            <li>
                <strong> switzerland: </strong> 
                <?php
                    echo ($id-> supplier_personal ==1)?"Yes":"No";
                ?>
            </li>
    </ul>
</div>


<p>
    <strong>Description: </strong> <br>   <?php echo e($id->target_group_desc); ?>

</p>
    

<?php /**PATH /home2/richdilly/crm.dillahunty.space/resources/views/customer/show.blade.php ENDPATH**/ ?>