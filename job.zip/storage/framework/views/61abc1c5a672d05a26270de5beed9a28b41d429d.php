<div>

    <h1>Hello!</h1>
    <h4>My name is <?php echo e($name); ?> </h3>
    <h4>This is my E-mail address <?php echo e($email); ?></h4>
    <h5><?php echo e($phone); ?></h5>
    <h4>Proposals:</h4>
    <h6>
        <?php echo e($porposal); ?>

    </h6>      
    
</div><?php /**PATH E:\2019\Andreas\job\resources\views/emails/contact.blade.php ENDPATH**/ ?>